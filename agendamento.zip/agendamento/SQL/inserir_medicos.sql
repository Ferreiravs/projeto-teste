INSERT INTO medico (nome, crm, especialidade, telefone, hora_inicio, hora_fim, sala) VALUES
-- Cardiologistas
('Dr. João Silva', 123456, 'Cardiologista', '1234-5678', '08:00:00', '12:00:00', 'Sala 101'),
('Dr. Rafael Torres', 123457, 'Cardiologista', '1234-5679', '12:00:00', '16:00:00', 'Sala 201'),
('Dra. Camila Mendes', 123458, 'Cardiologista', '1234-5680', '16:00:00', '20:00:00', 'Sala 202'),
('Dr. Bruno Rocha', 123459, 'Cardiologista', '1234-5681', '20:00:00', '00:00:00', 'Sala 203'),
('Dr. Felipe Nunes', 123460, 'Cardiologista', '1234-5682', '00:00:00', '04:00:00', 'Sala 204'),
('Dra. Larissa Teixeira', 123461, 'Cardiologista', '1234-5683', '04:00:00', '08:00:00', 'Sala 205'),

-- Dermatologistas
('Dra. Maria Oliveira', 234567, 'Dermatologista', '2345-6789', '09:00:00', '13:00:00', 'Sala 102'),
('Dr. Lucas Barros', 234568, 'Dermatologista', '2345-6790', '13:00:00', '17:00:00', 'Sala 206'),
('Dra. Natália Ferreira', 234569, 'Dermatologista', '2345-6791', '17:00:00', '21:00:00', 'Sala 207'),
('Dr. Eduardo Lima', 234570, 'Dermatologista', '2345-6792', '21:00:00', '01:00:00', 'Sala 208'),
('Dra. Bruna Martins', 234571, 'Dermatologista', '2345-6793', '01:00:00', '05:00:00', 'Sala 209'),
('Dr. André Souza', 234572, 'Dermatologista', '2345-6794', '05:00:00', '09:00:00', 'Sala 210'),

-- Pediatras
('Dr. Pedro Santos', 345678, 'Pediatra', '3456-7890', '10:00:00', '14:00:00', 'Sala 103'),
('Dra. Helena Moraes', 345679, 'Pediatra', '3456-7891', '14:00:00', '18:00:00', 'Sala 211'),
('Dr. Tiago Cunha', 345680, 'Pediatra', '3456-7892', '18:00:00', '22:00:00', 'Sala 212'),
('Dra. Priscila Duarte', 345681, 'Pediatra', '3456-7893', '22:00:00', '02:00:00', 'Sala 213'),
('Dr. Marcos Vieira', 345682, 'Pediatra', '3456-7894', '02:00:00', '06:00:00', 'Sala 214'),
('Dra. Juliana Reis', 345683, 'Pediatra', '3456-7895', '06:00:00', '10:00:00', 'Sala 215'),

-- Neurologistas
('Dra. Ana Costa', 456789, 'Neurologista', '4567-8901', '11:00:00', '15:00:00', 'Sala 104'),
('Dr. Leandro Faria', 456790, 'Neurologista', '4567-8902', '15:00:00', '19:00:00', 'Sala 216'),
('Dra. Tatiane Lopes', 456791, 'Neurologista', '4567-8903', '19:00:00', '23:00:00', 'Sala 217'),
('Dr. Rodrigo Azevedo', 456792, 'Neurologista', '4567-8904', '23:00:00', '03:00:00', 'Sala 218'),
('Dra. Isabela Rocha', 456793, 'Neurologista', '4567-8905', '03:00:00', '07:00:00', 'Sala 219'),
('Dr. Gustavo Pires', 456794, 'Neurologista', '4567-8906', '07:00:00', '11:00:00', 'Sala 220'),

-- Ortopedistas
('Dr. Carlos Lima', 567890, 'Ortopedista', '5678-9012', '12:00:00', '16:00:00', 'Sala 105'),
('Dr. Rafael Menezes', 567891, 'Ortopedista', '5678-9013', '16:00:00', '20:00:00', 'Sala 221'),
('Dra. Aline Costa', 567892, 'Ortopedista', '5678-9014', '20:00:00', '00:00:00', 'Sala 222'),
('Dr. Daniel Brito', 567893, 'Ortopedista', '5678-9015', '00:00:00', '04:00:00', 'Sala 223'),
('Dra. Renata Lopes', 567894, 'Ortopedista', '5678-9016', '04:00:00', '08:00:00', 'Sala 224'),
('Dr. Igor Almeida', 567895, 'Ortopedista', '5678-9017', '08:00:00', '12:00:00', 'Sala 225'),

-- Ginecologistas
('Dra. Fernanda Souza', 678901, 'Ginecologista', '6789-0123', '13:00:00', '17:00:00', 'Sala 106'),
('Dr. Henrique Vidal', 678902, 'Ginecologista', '6789-0124', '17:00:00', '21:00:00', 'Sala 226'),
('Dra. Paula Figueiredo', 678903, 'Ginecologista', '6789-0125', '21:00:00', '01:00:00', 'Sala 227'),
('Dr. Diego Martins', 678904, 'Ginecologista', '6789-0126', '01:00:00', '05:00:00', 'Sala 228'),
('Dra. Carolina Andrade', 678905, 'Ginecologista', '6789-0127', '05:00:00', '09:00:00', 'Sala 229'),
('Dr. Eduardo Monteiro', 678906, 'Ginecologista', '6789-0128', '09:00:00', '13:00:00', 'Sala 230');
