CREATE TABLE atendimento (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    especialidade VARCHAR(255),
    telefone VARCHAR(255),
    data DATE,
    hora TIME,
    sala VARCHAR(255),
    paciente_id BIGINT,
    FOREIGN KEY (paciente_id) REFERENCES paciente(id)
);
