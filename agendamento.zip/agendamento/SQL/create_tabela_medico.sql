CREATE TABLE medico (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255),
    especialidade VARCHAR(255),
    horario_inicio TIME,
    horario_fim TIME,
    telefone VARCHAR(255),
    sala VARCHAR(255),
    crm VARCHAR(255)
);
