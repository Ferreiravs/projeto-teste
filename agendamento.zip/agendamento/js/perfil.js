function carregarDadosPaciente() {
    const token = localStorage.getItem("token");
    if (!token) {
        console.error("Token não encontrado");
        return;
    }

    console.log("Token enviado:", token); // Log para verificar o token

    fetch("http://localhost:8080/pacientes/perfil", {
        headers: {
            "Authorization": `Bearer ${token}`
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Erro ao buscar dados do paciente");
        }
        return response.json();
    })
    .then(data => {
        const tbody = document.querySelector("#tabela-pacientes tbody");
        tbody.innerHTML = `
            <tr>
                <td>${data.nome}</td>
                <td>${data.dataNascimento}</td>
                <td>${data.sexo}</td>
                <td>${data.telefone}</td>
                <td><button class="btn btn-sm btn-primary">Editar</button></td>
            </tr>
        `;
    })
    .catch(error => {
        console.error(error);  // Mais informações no console para depuração
        alert("Erro ao buscar dados do paciente");
    });
}
